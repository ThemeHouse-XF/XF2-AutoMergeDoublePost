<?php

namespace KL\AutoMergeDoublePost;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerUpgradeTrait;
use XF\Entity\PermissionEntry;

class Setup extends AbstractSetup
{
    use StepRunnerUpgradeTrait;

    public function install(array $stepParams = [])
    {
    }

    public function upgrade1010151Step1()
    {
        \XF::db()->beginTransaction();

        $perms = \XF::finder('XF:PermissionEntry')
            ->where('permission_id', '=', 'klAMDPMergeTime')
            ->where('permission_value_int', '<>', '-1')
            ->fetch();

        foreach ($perms as $perm) {
            /** @var PermissionEntry $perm */
            $perm->fastUpdate('permission_value_int', $perm->permission_value_int * 60);
        }

        $this->app->jobManager()->enqueue('XF:PermissionRebuild');

        \XF::db()->commit();
    }

    public function uninstall(array $stepParams = [])
    {
    }
}